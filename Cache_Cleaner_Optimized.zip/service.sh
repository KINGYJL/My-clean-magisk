#!/system/bin/sh
# Magisk 服务脚本，定期执行清理

MODDIR=${0%/*}

# 使用 at 命令定时执行，避免 while true 死循环
echo "sh $MODDIR/cache_cleaner.sh" | at now + 12 hours
