#!/system/bin/sh
# Android 定时清理缓存脚本（优化版）

if [ $(id -u) -ne 0 ]; then
    echo "请使用 root 权限运行此脚本"
    exit 1
fi

CACHE_DIRS=(
    "/data/cache"
    "/data/system_cache"
    "/data/log"
    "/sdcard/Android/data/*/cache"
    "/sdcard/Android/obb/*/cache"
    "/data/tombstones"
    "/data/anr"
    "/sdcard/tencent/MicroMsg/Cache"
    "/sdcard/tencent/MobileQQ/log"
    "/sdcard/Android/data/org.telegram.messenger/cache"
    "/storage/emulated/0/Android/data/org.telegram.messenger/files/Telegram/"
)

# 排除特定应用缓存（如微信、QQ、哔哩哔哩等）
EXCLUDE_DIRS=(
    "/sdcard/Android/data/com.tencent.mm/cache"
    "/sdcard/Android/data/com.tencent.mobileqq/cache"
    "/sdcard/Android/data/com.bilibili.app.cache"
)

LOG_DIR="/sdcard/Android/cache_cleaner"
LOG_FILE="$LOG_DIR/cache_cleaner.log"
mkdir -p "$LOG_DIR"

echo "$(date): 开始清理缓存" >> "$LOG_FILE"

for dir in "${CACHE_DIRS[@]}"; do
    SKIP=0
    for exclude in "${EXCLUDE_DIRS[@]}"; do
        if [[ "$dir" == "$exclude" ]]; then
            SKIP=1
            break
        fi
    done
    if [ $SKIP -eq 0 ] && [ -d "$dir" ]; then
        echo "清理: $dir" >> "$LOG_FILE"
        rm -rf "$dir"/*
    fi
done

# 释放缓存，但降低频率（每 24 小时执行一次）
if [ $(date +%H) -eq 0 ]; then
    sync; echo 3 > /proc/sys/vm/drop_caches
    echo "$(date): 内存缓存已释放" >> "$LOG_FILE"
fi

echo "$(date): 缓存清理完成" >> "$LOG_FILE"
